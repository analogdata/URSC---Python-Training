# stringcase-utils

A simple Python package to convert strings between snake_case and camelCase.
