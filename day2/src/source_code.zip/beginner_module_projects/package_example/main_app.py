from my_package.subpackage_b import module_b

print(module_b.func_b())
