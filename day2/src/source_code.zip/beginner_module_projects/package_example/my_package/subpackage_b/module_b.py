from my_package.subpackage_a import module_a

def func_b():
    return f"Result from func_b, using {module_a.func_a()}"
