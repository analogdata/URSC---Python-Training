def func_a():
    return "Result from func_a"
