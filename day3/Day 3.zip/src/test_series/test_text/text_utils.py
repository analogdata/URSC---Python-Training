# text_utils.py

def shout(text):
    return text.upper() + "!"